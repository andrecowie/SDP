This file contained 2 files which are:the .exe file and unity package 
file.

----------------------------------------------------------------------
Control:
WASD or the arrow button to move.
Space to Jump
J to shoot bullets
C to open stats
P to pause and open weapon menu/save/quit

Don't touch the enemy otherwise you will get damaged.

----------------------------------------------------------------------
In this Demo, we have coded and apply interaction with NPCs and GUI menu,
this Demo is simply show how functions works.